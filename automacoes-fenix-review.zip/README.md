# Automações Web – Fênix Internet 🚀

Este repositório centraliza todas as automações web da empresa (Python + Playwright).

## Estrutura
python agent.py   # inicia o agente e as hotkeys
Ctrl+F7           # dispara automacao1
Ctrl+Shift+Q      # encerra o agente


## Como usar
1. `pip install -r requirements.txt`
2. `playwright install`
3. `python automacao1/main.py`
